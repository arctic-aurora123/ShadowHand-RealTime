The XML file inside this folder defines the Shadow hand model for Simox.

Simox (http://simox.sourceforge.net) is a leightweight platform indepedent C++ toolbox containing three libraries for 3D simulation of robot systems, sampling based motion planning and grasp planning.
