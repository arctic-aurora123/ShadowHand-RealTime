import os
import numpy as np
import os.path as osp
from pyrfuniverse.envs.base_env import RFUniverseBaseEnv
import pyrfuniverse.attributes as attr

env = RFUniverseBaseEnv()

shadow = env.LoadURDF(path=os.path.abspath(osp.join('gripper', 'shadow.urdf')), native_ik=False)

shadow.SetTransform(position=[0, 1, 0], rotation=[0, 90, 0])
env.SetViewTransform(position=[0, 1.3, -0.4])
env.step(1)
env.ViewLookAt((np.asarray(shadow.data['position']) + np.asarray([0, 0.3, 0])).tolist())
env.step(5)
moveable_joint_count = shadow.data["number_of_moveable_joints"]
print(f"moveable_joint_count:{moveable_joint_count}")

upper_limit = np.asarray(shadow.data['joint_upper_limit'])

idx = np.asarray([0, 1, 2, 4, 7, 8, 12, 16, 20])
upper_limit[idx] = 0.0

for idx in range(30):
    set_angle = upper_limit * idx / 30.0
    # use this function to set joint parameter of shadow hand, the joint angle is described in degree measure
    shadow.SetJointPositionDirectly(set_angle.tolist())
    # use env.step() to update the hand rendered in the simulation
    env.step(5)

env.Pend()
env.close()